﻿using BAL;
using DAL;
using JobAlert.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ModelLayer;
namespace JobAlert.Controllers
{
    public class HomeController : Controller
    {
        NotificationBal objNotificationBal = new NotificationBal();
        public ActionResult Index()
        {
            NotificationVM objNotificationVMList = new NotificationVM();
            List<NotisificationML> obj = new List<NotisificationML>();
            obj = objNotificationBal.GetNotification();
            objNotificationVMList.NotificationList = obj;
            obj = objNotificationBal.GetCategoryJob();
            objNotificationVMList.Job = obj;
            obj = objNotificationBal.GetCategoryAdmitCard();
            objNotificationVMList.AdmitCard = obj;
            obj = objNotificationBal.GetCategoryResult();
            objNotificationVMList.Result = obj;
          //  ViewBag.Message = "Modify this template to jump-start your ASP.NET MVC application.";

            return View(objNotificationVMList);
        }
        public ActionResult CategoryData(int id)
        {
            List<CommonDetailML> obj = new List<CommonDetailML>();
            CommonDetailsVM objCommonDetails = new CommonDetailsVM();
            obj = objNotificationBal.GetImpDates(id);
            objCommonDetails.objImportentDate = obj;
            obj = objNotificationBal.GetAGE_LIMIT(id);
            objCommonDetails.objAgeLimit = obj;
            obj = objNotificationBal.GetAPP_FEE(id);
            objCommonDetails.objApplicationFee = obj;
            obj = objNotificationBal.GetAGE_LIMIT(id);
            objCommonDetails.objAgeLimit = obj;
            obj = objNotificationBal.GetEligibility(id);
            objCommonDetails.objEligibility = obj;
            obj = objNotificationBal.GetVacancy(id);
            objCommonDetails.objVacancy = obj;
            objCommonDetails.Links = objNotificationBal.GetApplicationLink(id);
            objCommonDetails.ShortInformation = objNotificationBal.GetShortInformation(id);

            return View(objCommonDetails);
        }
        public ActionResult LetestJobs()
        {
            return View();
        }

    }
}
