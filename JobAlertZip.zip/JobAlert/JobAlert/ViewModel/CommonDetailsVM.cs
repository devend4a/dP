﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ModelLayer;
namespace JobAlert.ViewModel
{
    public class CommonDetailsVM
    {
        public List<CommonDetailML> objCommonDetailML = new List<CommonDetailML>();
        public List<CommonDetailML> objImportentDate;
        public List<CommonDetailML> objAgeLimit;
        public List<CommonDetailML> objApplicationFee;
        public List<CommonDetailML> objImportentDta;
        public List<CommonDetailML> objEligibility;
        public List<CommonDetailML> objVacancy;
        public List<NotisificationML> ShortInformation;
        public List<LinkML> Links;
        public int Id { get; set; }
        public Nullable<int> NotificationId { get; set; }
        public string Title { get; set; }
        public string Contents { get; set; }
        public string Category { get; set; }

    }
}