﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ModelLayer;
namespace DAL
{
    public class NotificationDal
    {
        //Notification
        public List<NotisificationML> GetNotification()
        {
            List<NotisificationML> objNotificationML = null;

            using (SarkariEntities obj = new SarkariEntities())
            {
                objNotificationML = new List<NotisificationML>();
                objNotificationML = (from x in obj.Notisifications
                                     select new NotisificationML
                                         {
                                             Id = x.Id,
                                             NameoPost = x.NameoPost,
                                             PostDate = x.PostDate,
                                             PostUpdatePost = x.PostUpdatePost,
                                             ApplicationBegin = x.ApplicationBegin,
                                             ShortInfo = x.ShortInfo,
                                             LastDateRegistration = x.LastDateRegistration,
                                             Category = x.Category
                                         }).ToList();
            }

            return objNotificationML;
        }
        //JOB
        public List<NotisificationML> GetCategoryJob()
        {
            List<NotisificationML> objCategoryJob = null;
            using (SarkariEntities obj = new SarkariEntities())
            {
                objCategoryJob = (from job in obj.Notisifications
                                  where job.Category == "JOB"
                                  select new NotisificationML
                                  {
                                      NameoPost = job.NameoPost,
                                      Id = job.Id
                                  }).ToList();
                return objCategoryJob;
            }
        }
        //Admit
        public List<NotisificationML> GetCategoryAdmitCard()
        {
            List<NotisificationML> objCategoryJob = null;
            using (SarkariEntities obj = new SarkariEntities())
            {
                objCategoryJob = (from job in obj.Notisifications
                                  where job.Category == "ADMIT"
                                  select new NotisificationML
                                  {
                                      NameoPost = job.NameoPost
                                  }).ToList();
                return objCategoryJob;
            }
        }
        //Result
        public List<NotisificationML> GetCategoryResult()
        {
            List<NotisificationML> objCategoryJob = null;
            using (SarkariEntities obj = new SarkariEntities())
            {
                objCategoryJob = (from job in obj.Notisifications
                                  where job.Category == "RESULT"
                                  select new NotisificationML
                                  {
                                      NameoPost = job.NameoPost
                                  }).ToList();
                return objCategoryJob;
            }
        }
        public List<CommonDetailML> GetImpDates(int id)
        {
            List<CommonDetailML> CommonLists = null;
            using (SarkariEntities obj = new SarkariEntities())
            {
                CommonLists = (from Imp in obj.CommonDetails
                               where Imp.NotificationId == id && Imp.Category == "IMP_DATES"
                               select new CommonDetailML
                              {
                                  Id = Imp.Id,
                                  Category = Imp.Category,
                                  Title = Imp.Title,
                                  Contents = Imp.Contents

                              }).ToList();
                return CommonLists;
            }
        }
        public List<CommonDetailML> GetAGE_LIMIT(int id)
        {
            List<CommonDetailML> CommonLists = null;
            using (SarkariEntities obj = new SarkariEntities())
            {
                CommonLists = (from Imp in obj.CommonDetails
                               where Imp.NotificationId == id && Imp.Category == "AGE_LIMIT"
                               select new CommonDetailML
                               {
                                   Id = Imp.Id,
                                   Category = Imp.Category,
                                   Title = Imp.Title,
                                   Contents = Imp.Contents

                               }).ToList();
                return CommonLists;
            }
        }
        public List<CommonDetailML> GetAPP_FEE(int id)
        {
            List<CommonDetailML> CommonLists = null;
            using (SarkariEntities obj = new SarkariEntities())
            {
                CommonLists = (from Imp in obj.CommonDetails
                               where Imp.NotificationId == id && Imp.Category == "APP_FEE"
                               select new CommonDetailML
                               {
                                   Id = Imp.Id,
                                   Category = Imp.Category,
                                   Title = Imp.Title,
                                   Contents = Imp.Contents

                               }).ToList();
                return CommonLists;
            }
        }
        public List<CommonDetailML> GetEligibility(int id)
        {
            List<CommonDetailML> CommonLists = null;
            using (SarkariEntities obj = new SarkariEntities())
            {
                CommonLists = (from Imp in obj.CommonDetails
                               where Imp.NotificationId == id && Imp.Category == "Eligibility"
                               select new CommonDetailML
                               {
                                   Id = Imp.Id,
                                   Category = Imp.Category,
                                   Title = Imp.Title,
                                   Contents = Imp.Contents

                               }).ToList();
                return CommonLists;
            }
        }
        public List<CommonDetailML> GetVacancy(int id)
        {
            List<CommonDetailML> CommonLists = null;
            using (SarkariEntities obj = new SarkariEntities())
            {
                CommonLists = (from Imp in obj.CommonDetails
                               where Imp.NotificationId == id && Imp.Category == "Vacancy"
                               select new CommonDetailML
                               {
                                   Id = Imp.Id,
                                   Category = Imp.Category,
                                   Title = Imp.Title,
                                   Contents = Imp.Contents

                               }).ToList();
                return CommonLists;
            }
        }
        public List<NotisificationML> GetShortInformation(int id)
        {
            List<NotisificationML> CommonLists = new List<NotisificationML>();
            using (SarkariEntities obj = new SarkariEntities())
            {
                CommonLists = (from Imp in obj.Notisifications
                               where Imp.Id == id
                               select new NotisificationML
                               {
                                   NameoPost = Imp.NameoPost,
                                   PostDate = Imp.PostDate,
                                   PostUpdatePost = Imp.PostUpdatePost,
                                   ShortInfo = Imp.ShortInfo

                               }).ToList();

            }
            return CommonLists;
        }
        public List<LinkML> GetApplicationLink(int id)
        {
            List<LinkML> CommonLists = new List<LinkML>();
            using (SarkariEntities obj = new SarkariEntities())
            {
                CommonLists = (from Imp in obj.Links
                               where Imp.NotificationID == id
                               select new LinkML
                               {
                                   Title = Imp.Title,
                                   Link1 = Imp.Link1
                               }).ToList();

            }
            return CommonLists;
        }

    }
}


//SELECT * FROM CommonDetail WHERE Category='IMP_DATES' AND NotificationId=1 