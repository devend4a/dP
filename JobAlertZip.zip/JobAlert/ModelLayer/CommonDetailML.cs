﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ModelLayer
{
    public class CommonDetailML
    {
        public List<NotisificationML> GetShortInformation;
        public int Id { get; set; }
        public Nullable<int> NotificationId { get; set; }
        public string Title { get; set; }
        public string Contents { get; set; }
        public string Category { get; set; }
    }
}
