﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ModelLayer
{
    class AdmitCardML
    {
        public int Id { get; set; }
        public string NameOfPost { get; set; }
        public Nullable<System.DateTime> PostDate { get; set; }
        public Nullable<System.DateTime> LastDate { get; set; }
    }
}
