﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ModelLayer
{
  public  class NotisificationML
    {
        public int Id { get; set; }
        public string NameoPost { get; set; }
        public Nullable<System.DateTime> PostDate { get; set; }
        public Nullable<System.DateTime> PostUpdatePost { get; set; }
        public string ShortInfo { get; set; }
        public Nullable<System.DateTime> ApplicationBegin { get; set; }
        public Nullable<System.DateTime> LastDateRegistration { get; set; }
        public string Category { get; set; }
    }
}
