﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ModelLayer
{
    class PostML
    {
        public int Id { get; set; }
        public Nullable<int> NotificationId { get; set; }
        public string Title { get; set; }
        public Nullable<int> Count { get; set; }
    }
}
