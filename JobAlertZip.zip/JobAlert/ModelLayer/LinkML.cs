﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ModelLayer
{
  public   class LinkML
    {
        public int Id { get; set; }
        public Nullable<int> NotificationID { get; set; }
        public string Title { get; set; }
        public string Link1 { get; set; }
    }
}
