﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ModelLayer;
using DAL;
namespace BAL
{
    public class NotificationBal
    {
        NotificationDal objDal = new NotificationDal();
        public List<NotisificationML> GetNotification()
        {
            return objDal.GetNotification();
        }
        public List<NotisificationML> GetCategoryJob()
        {
            return objDal.GetCategoryJob();
        }
        public List<NotisificationML> GetCategoryAdmitCard()
        {
            return objDal.GetCategoryAdmitCard();
        }
        public List<NotisificationML> GetCategoryResult()
        {
            return objDal.GetCategoryResult();
        }
        //detailsData
        public List<CommonDetailML> GetImpDates(int id)
        {
            return objDal.GetImpDates(id);

        }
        public List<CommonDetailML> GetAGE_LIMIT(int id)
        {
            return objDal.GetAGE_LIMIT(id);
        }
        public List<CommonDetailML> GetAPP_FEE(int id)
        {
            return objDal.GetAPP_FEE(id);
        }
        public List<CommonDetailML> GetEligibility(int id)
        {
            return objDal.GetEligibility(id);
        }
        public List<CommonDetailML> GetVacancy(int id)
        {

            return objDal.GetVacancy(id);

        }
        public List<NotisificationML> GetShortInformation(int id)
        {

            return objDal.GetShortInformation(id);

        }
        public List<LinkML> GetApplicationLink(int id)
        {

            return objDal.GetApplicationLink(id);
        }
    }
}
